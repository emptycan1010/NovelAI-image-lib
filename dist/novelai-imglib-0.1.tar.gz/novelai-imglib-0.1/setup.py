from setuptools import setup, find_packages


setup(
    name="novelai-imglib",
    version="0.1",
    description="NovelAI-Image Library for python ",
    author="emptycan1010",
    author_email="siro157@duck.com",
    url="https://github.com/emptycan1010",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    py_modules=["requestimg"],
    python_requires=">=3.10",
    packages=find_packages(),
)
